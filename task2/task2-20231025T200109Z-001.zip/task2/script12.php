<?php
$str1="Hello";
$str2="World!";
$con=$str1.$str2;
echo "$con";
?>