<?php
$n = 10;  

$f = 1; 

for ($i=1; $i <= $n; $i++) {  
  $f = $f * $i;  
} 
/*Display the output.*/
echo "Factorial of $n is $f";  
?>