<?php
$num1 = 10;
$num2 = 25;
$num3 = 50;

$largest = max($num1, $num2, $num3);

echo "The largest number among $num1, $num2, and $num3 is: $largest";
?>