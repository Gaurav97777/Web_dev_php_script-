<?php
$number = 100; 

$squareRoot = sqrt($number);

echo "The square root of $number is: $squareRoot";
?>