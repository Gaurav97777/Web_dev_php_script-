<?php  
 $length = 10;  
 $width = 8;  
 echo "Area of rectangle is $length * $width= " . $length * $width . "<br />";  
  ?>  