<?php
$temp=10;
$fer=($temp*9/5)+32;
echo($fer);
?>