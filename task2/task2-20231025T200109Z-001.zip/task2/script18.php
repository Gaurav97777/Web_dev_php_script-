<?php
$num1 = rand();
  
echo "Random number: " . $num1 . "\n";
  
$num2 = rand(1, 10);
    
echo "Random number in range (1, 10): ", $num2;
  
?>