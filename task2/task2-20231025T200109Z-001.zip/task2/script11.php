<?php
$num=20;
if($num%2==0)
{
	echo "Number is even";
}
else
{
	echo "Number is odd";
}
?>