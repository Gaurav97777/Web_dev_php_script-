<?php
$num1 = 10;
$num2 = 20;

$num1 = $num1 + $num2;
$num2 = $num1 - $num2;
$num1 = $num1 - $num2;

echo "After swapping: num1 = $num1, num2 = $num2";
?>